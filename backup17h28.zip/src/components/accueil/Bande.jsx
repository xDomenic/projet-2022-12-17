import React from "react";

const Bande = () => {
  return (
    <section
      className="newsletter-area newsletter-bg"
      style={{ backgroundImage: 'url("../img/bg/newsletter_bg.jpg")' }}
    >
      <div className="container">
        <div className="newsletter-inner-wrap">
          <div className="row align-items-center">
            <div className="col-lg-6"></div>
            <div className="col-lg-6"></div>
          </div>
        </div>
      </div>
    </section>
  );
};
export default Bande;
